class Obstacle {
  constructor(x, y) {
      this.pos = createVector(x, y);
      this.size = 70; // Cambia le dimensioni degli ostacoli
      this.speed = random(4, 17);
  }

  update() {
      this.pos.x -= this.speed; // Cambia la direzione del movimento da destra a sinistra
      if (this.pos.x < -this.size / 2) { // Controlla se l'ostacolo è fuori dallo schermo a sinistra
          this.pos.x = width + this.size / 2; // Riporta l'ostacolo dall'altra parte dello schermo
          this.pos.y = random(height); // Rigenera la posizione verticale dell'ostacolo
          this.speed = random(1, 17); // Rigenera la velocità dell'ostacolo
      }
  }

  show() {
      image(obstacleImg, this.pos.x, this.pos.y, this.size, this.size); // Mostra l'immagine degli ostacoli
  }
}

  