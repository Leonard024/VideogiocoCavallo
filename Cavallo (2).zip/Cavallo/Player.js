class Player {
  constructor() {
    this.pos = createVector(50, 50);
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.size = 1000; // Dimensione del personaggio (predefinita)
    this.speed = 3;
    this.score = 0;
    this.isMovingUp = false;
    this.isMovingDown = false;
    this.isMovingLeft = false;
    this.isMovingRight = false;
  }

  // Metodo per impostare la dimensione del personaggio
  setSize(newSize) {
    this.size = newSize;
  }

  update() {
    this.vel.add(this.acc);
    this.vel.limit(3); // Limita la velocità massima
    this.pos.add(this.vel);
    this.acc.set(0, 0);
    this.pos.x = constrain(this.pos.x, 0, width);
    this.pos.y = constrain(this.pos.y, 0, height);
  }

  show() {
    image(playerImg, this.pos.x, this.pos.y, this.size, this.size);
  }

  handleMovement() {
    if (this.isMovingUp) {
      this.acc.add(0, -35); // Aumenta leggermente l'accelerazione
    } else if (this.isMovingDown) {
      this.acc.add(0, 35); // Aumenta leggermente l'accelerazione
    }
    if (this.isMovingLeft) {
      this.acc.add(-35, 0); // Aumenta leggermente l'accelerazione
    } else if (this.isMovingRight) {
      this.acc.add(35, 0); // Aumenta leggermente l'accelerazione
    }
  }

  handleKeyPress(key) {
    if (key === 'w' || key === 'W') {
      this.isMovingUp = true;
    } else if (key === 's' || key === 'S') {
      this.isMovingDown = true;
    }
    if (key === 'a' || key === 'A') {
      this.isMovingLeft = true;
    } else if (key === 'd' || key === 'D') {
      this.isMovingRight = true;
    }
  }

  handleKeyRelease(key) {
    if (key === 'w' || key === 'W') {
      this.isMovingUp = false;
    } else if (key === 's' || key === 'S') {
      this.isMovingDown = false;
    }
    if (key === 'a' || key === 'A') {
      this.isMovingLeft = false;
    } else if (key === 'd' || key === 'D') {
      this.isMovingRight = false;
    }
  }

  hits(obstacle) {
    let d = dist(this.pos.x, this.pos.y, obstacle.pos.x, obstacle.pos.y);
    if (d < this.size / 2 + obstacle.size / 2) {
      return true;
    } else {
      return false;
    }
  }
}

