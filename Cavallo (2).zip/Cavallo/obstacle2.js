/*
let ostacolo = []; // Array degli ostacoli
let numOstacoli;

function setup() {
  createCanvas(400, 400);
  
  // Imposta il numero casuale di ostacoli tra 5 e 10
  numOstacoli = floor(random(5, 11));
  
  // Genera ostacoli casuali
  for (let i = 0; i < numOstacoli; i++) {
    let ostacoloX = random(width - 100); // Posizione casuale lungo l'asse x
    let ostacoloY = random(height - 100); // Posizione casuale lungo l'asse y
    let ostacoloWidth = random(20, 100); // Larghezza casuale
    let ostacoloHeight = random(20, 100); // Altezza casuale
    
    ostacoli.push(new Obstacle(ostacoloX, ostacoloY, ostacoloWidth, ostacoloHeight));
  }
}

function draw() {
  background(220);
  
  // Mostra e muovi gli ostacoli
  for (let ostacolo of ostacoli) {
    ostacolo.show();
  }
}
*/
// Classe dell'ostacolo
// class Ostacolo {
//   constructor(x, y, w, h) {
//     this.x = x;
//     this.y = y;
//     this.w = w;
//     this.h = h;
//   }

//   show() {
//     fill(255, 0, 0);
//     rect(this.x, this.y, this.w, this.h);
//   }
// }
