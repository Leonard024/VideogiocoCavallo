let player;
let obstacles = [];
let endPoint;
let score = 0;
let gameIsOver = false;
let ostacolo = []; // Array degli ostacoli
let numOstacoli;
let buttonN;
let startTime; // Variabile per memorizzare il tempo di inizio del gioco
let lastObstacleIncrease = 0;
let obstacleIncreaseInterval = 10000; // Intervallo di tempo per l'aumento degli ostacoli (in millisecondi)
let backgroundChangeInterval = 10000; // Intervallo di tempo per il cambio dello sfondo (in millisecondi)
let lastBackgroundChange = 0;
let backgroundChanges = 0; // Numero di volte che lo sfondo è stato cambiato
let currentBackground = 1; // Indice dello sfondo attualmente visualizzato

function preload() {
  playerImg = loadImage('personaggio.gif'); // Carica l'immagine del giocatore
  obstacleImg = loadImage('ostacolo1.png'); // Carica l'immagine degli ostacoli
  backgroundImage1 = loadImage('sfondo2.gif');
  backgroundImage2 = loadImage('sfondo1.gif');
  backgroundImage3 = loadImage('sfondo.gif');
  backgroundImage4 = loadImage('gameover.gif');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  fullscreen(true); // Imposta il canvas a schermo intero
  player = new Player();
  player.setSize(100); // Imposta la dimensione del personaggio 

  // Creazione degli ostacoli
  for (let i = 0; i < 5; i++) {
    let obstacle = new Obstacle(random(width), random(height));
    obstacles.push(obstacle);
  }

  startTime = millis(); // Salva il tempo di inizio del gioco
}

function draw() {
  // Verifica se è il momento di cambiare lo sfondo
  if (millis() - lastBackgroundChange > backgroundChangeInterval && backgroundChanges < 3) {
    changeBackground();
    lastBackgroundChange = millis();
    backgroundChanges++;
  }

  // Disegna lo sfondo attuale
  switch (currentBackground) {
    case 1:
      background(backgroundImage1);
      break;
    case 2:
      background(backgroundImage2);
      break;
    case 3:
      background(backgroundImage3);
      break;
  }

  // Controlla il movimento del giocatore 
  player.handleMovement();

  // Muove e disegna il giocatore
  player.update();
  player.show();

  // Muove e disegna gli ostacoli
  for (let obstacle of obstacles) {
    obstacle.update();
    obstacle.show();
  }

  // Controlla se il giocatore ha colpito un ostacolo
  for (let obstacle of obstacles) {
    if (player.hits(obstacle)) {
      GameOverScreen();
      gameIsOver = true;
      noLoop(); // Ferma il loop draw()
    }
  }

  // Aumenta gli ostacoli a intervalli regolari
  if (millis() - lastObstacleIncrease > obstacleIncreaseInterval) {
    increaseObstacles();
    lastObstacleIncrease = millis();
  }

  // Calcola lo score basato sul tempo trascorso
  score = floor((millis() - startTime) / 1000); // Converti i millisecondi in secondi 
}

function keyPressed() {
  if (key === 'W' || key === 'w') {
    player.isMovingUp = true;
  } else if (key === 'S' || key === 's') {
    player.isMovingDown = true;
  }
  if (key === 'A' || key === 'a') {
    player.isMovingLeft = true;
  } else if (key === 'D' || key === 'd') {
    player.isMovingRight = true;
  }
}

function keyReleased() {
  if (key === 'W' || key === 'w') {
    player.isMovingUp = false;
  } else if (key === 'S' || key === 's') {
    player.isMovingDown = false;
  }
  if (key === 'A' || key === 'a') {
    player.isMovingLeft = false;
  } else if (key === 'D' || key === 'd') {
    player.isMovingRight = false;
  }
}

function increaseObstacles() {
  // Aumenta il numero di ostacoli
  let numIncrease = 5;
  for (let i = 0; i < numIncrease; i++) {
    let obstacle = new Obstacle(random(width), random(height));
    obstacles.push(obstacle);
  }
}

function changeBackground() {
  // Cambia lo sfondo attuale
  currentBackground++;
  if (currentBackground > 3) {
    currentBackground = 1; // Torna al primo sfondo dopo il terzo
  }
}

function GameOverScreen() {
  // Interrompi la musica di sottofondo
  document.querySelector('audio').pause();

  background(backgroundImage4);
  textSize(20);
  fill(255, 180);
  textAlign(CENTER, CENTER);
  text("Punteggio totale: " + score, 1000, 500); // Utilizzo dei parametri x e y per posizionare lo score

  // Creo un bottone per iniziare una nuova partita
  buttonN = createButton('NEW GAME');
  let buttonX = 650; // Posizione x del pulsante
  let buttonY = 480; // Posizione y del pulsante
  let buttonWidth = 100; // Larghezza del pulsante
  let buttonHeight = 50; // Altezza del pulsante
  buttonN.position(buttonX, buttonY); // Imposto la posizione del pulsante
  buttonN.size(buttonWidth, buttonHeight); // Imposto le dimensioni del pulsante
  buttonN.mousePressed(function () {
    location.reload();
  });
}

